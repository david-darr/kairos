# Kairos iPhone spacing and swipe update

For your current full-screen/widgets project:

1. Quit the running Kairos app on your iPhone.
2. Unzip this patch on your Mac.
3. In Finder, open your existing KairosMobile project folder.
4. Replace App/KairosMobileApp.swift and App/ActivityModel.swift with the two files from this patch. Replace their contents/files; do not add duplicate Swift files to Xcode.
5. Open your existing KairosMobile.xcodeproj, select your iPhone, and press Cmd+R.
6. Return to Home, Chat, a Library document, and Forge. Check that controls stay below the status bar. Scroll a long page to inspect the parchment status blur. Scrollbars are hidden outside the chat transcript.
7. Swipe right from the left half of a page for the main menu. In Chat, swipe right across its header or from the right half of the transcript for Conversations. Swipe left to close either. Moderate diagonal swipes and short flicks work; editing and vertical scrolling remain available.

Keep your existing signing teams, bundle identifiers and App Group settings. No project or target changes are needed. The files preserve the full-screen shell, Live Activities and widget behavior and include the current usage-sharing code.

The web UI changes are already served by your private preview. Reopening/refreshing it loads the new web files. The patch adds native safe-area reporting after navigation/rotation, suppresses outer WKWebView scroll indicators, and disables native Back's competing swipe.

Validation: gesture policy, notification, activity/widget projection, JavaScript syntax and project structure checks pass. Windows blocked the Electron renderer; the contained browser was unavailable because Docker is not running. This revision has not been visually verified. Swift compilation and physical iPhone behavior need Xcode/device verification on your Mac.
