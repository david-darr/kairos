Kairos iPhone camera and microphone update

The web layout fixes load from your existing Kairos preview server.
This patch adds the native permission descriptions for Take a photo,
Dictate and Open Mic.

On your Mac:
1. Unzip this patch.
2. Open the folder containing your currently working Xcode project.
3. Replace its App/Info.plist with App/Info.plist from this patch.
4. Keep your existing signing team, identifiers and App Group settings.
5. In Xcode, run KairosMobile on your iPhone with Command-R.
6. In Chat, tap +, then Take a photo. Allow camera access if asked,
   take a photo and verify its attachment preview before sending.
7. Test Dictate/Open Mic when your Kairos server has a speech model set up.
   Audio is sent to that server for transcription.

If you have customized Info.plist, add only the NSCameraUsageDescription
and NSMicrophoneUsageDescription entries from the supplied file instead.

No Widget files or project/signing settings need replacing.
Plist and project checks passed on Windows. iPhone camera, microphone
and upload behavior still need device verification.
