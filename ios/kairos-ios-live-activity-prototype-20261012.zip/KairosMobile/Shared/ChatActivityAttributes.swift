import ActivityKit
import Foundation

// Compiled into both targets. No chat titles, text, or tool arguments on the Lock Screen.
struct ChatActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var state: String
        var startedAt: Double

        var label: String {
            switch state {
            case "awaiting_permission": return "Needs approval"
            case "completed": return "Reply ready"
            case "failed": return "Work failed"
            case "interrupted": return "Interrupted"
            case "stopped": return "Stopped"
            default: return "Working"
            }
        }

        var symbol: String {
            switch state {
            case "awaiting_permission": return "hand.raised.fill"
            case "completed": return "checkmark.circle.fill"
            case "failed", "interrupted": return "exclamationmark.triangle.fill"
            case "stopped": return "stop.circle.fill"
            default: return "sparkles"
            }
        }

        var terminal: Bool { ["completed", "failed", "stopped", "interrupted"].contains(state) }
    }

    var runID: String
    var sessionID: String
    var serverOrigin: String
    var accountID: String
    var isDemo: Bool

    var link: URL? {
        var parts = URLComponents()
        parts.scheme = "kairos-mobile"
        parts.host = isDemo ? "demo" : "chat"
        parts.queryItems = [URLQueryItem(name: "session", value: sessionID),
                            URLQueryItem(name: "origin", value: serverOrigin)]
        return parts.url
    }
}
