import ActivityKit
import SwiftUI
import WidgetKit

@main
struct KairosWidgetBundle: WidgetBundle {
    var body: some Widget { ChatLiveActivity() }
}

struct ChatLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: ChatActivityAttributes.self) { context in
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Label(context.attributes.isDemo ? "Kairos · Demo" : "Kairos", systemImage: "sparkles")
                        .font(.headline)
                    Spacer()
                    if !context.state.terminal {
                        Text(Date(timeIntervalSince1970: context.state.startedAt), style: .timer)
                            .monospacedDigit().font(.caption)
                    }
                }
                Label(context.isStale && !context.state.terminal ? "Open Kairos to refresh" : context.state.label,
                      systemImage: context.isStale && !context.state.terminal ? "arrow.clockwise" : context.state.symbol)
                    .font(.title3.weight(.semibold))
                Text(context.state.state == "awaiting_permission" ? "Open the chat to review the request." : "Tap to open Kairos.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(16)
            .activityBackgroundTint(Color(red: 0.08, green: 0.10, blue: 0.17))
            .activitySystemActionForegroundColor(.white)
            .foregroundStyle(.white)
            .widgetURL(context.attributes.link)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: context.state.symbol).foregroundStyle(tint(context.state)).padding(.leading, 4)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if !context.state.terminal {
                        Text(Date(timeIntervalSince1970: context.state.startedAt), style: .timer)
                            .monospacedDigit().font(.caption).padding(.trailing, 4)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(context.attributes.isDemo ? "Kairos · Demo" : "Kairos").font(.caption).foregroundStyle(.secondary)
                        Text(context.isStale && !context.state.terminal ? "Open to refresh" : context.state.label)
                            .font(.headline)
                        if context.state.state == "awaiting_permission" {
                            Text("Tap to review in chat").font(.caption)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                Image(systemName: context.isStale && !context.state.terminal ? "arrow.clockwise" : context.state.symbol)
                    .foregroundStyle(tint(context.state))
            } compactTrailing: {
                if context.state.state == "awaiting_permission" { Text("!").foregroundStyle(.orange).bold() }
                else if context.state.terminal { Image(systemName: context.state.symbol) }
                else if context.isStale { Image(systemName: "clock.badge.questionmark") }
                else { Text("…").accessibilityLabel("Working") }
            } minimal: {
                Image(systemName: context.isStale && !context.state.terminal ? "arrow.clockwise" : context.state.symbol)
                    .foregroundStyle(tint(context.state))
            }
            .widgetURL(context.attributes.link)
            .keylineTint(tint(context.state))
        }
    }

    private func tint(_ state: ChatActivityAttributes.ContentState) -> Color {
        switch state.state {
        case "awaiting_permission": return .orange
        case "completed": return .green
        case "failed", "interrupted": return .red
        default: return .cyan
        }
    }
}
