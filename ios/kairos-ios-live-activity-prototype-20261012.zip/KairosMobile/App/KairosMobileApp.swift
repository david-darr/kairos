import SwiftUI
import WebKit

@main
struct KairosMobileApp: App {
    @StateObject private var model = ActivityModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .onAppear { model.setForeground(scenePhase == .active) }
                .onChange(of: scenePhase) { _, phase in model.setForeground(phase == .active) }
                .onOpenURL { model.openLink($0) }
        }
    }
}

private struct KairosWebView: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

private struct ContentView: View {
    @ObservedObject var model: ActivityModel

    var body: some View {
        TabView(selection: $model.selectedTab) {
            KairosWebView(webView: model.webView)
                .tabItem { Label("Chat", systemImage: "bubble.left.and.bubble.right") }.tag(0)
            NavigationStack {
                List {
                    Section("Live Activity") {
                        Toggle("Follow active chats", isOn: Binding(get: { model.followEnabled },
                            set: { enabled in Task { await model.setFollowEnabled(enabled) } }))
                        Text("Follows one chat at a time, newest first. Updates while this app is open. Locking your phone shows the last status; it becomes stale after 45 seconds.")
                            .font(.footnote).foregroundStyle(.secondary)
                        if let activity = model.followed {
                            Label(activity.content.state.label, systemImage: activity.content.state.symbol)
                            if !activity.attributes.isDemo {
                                Button("Open followed chat") { model.openChat(activity.attributes.sessionID) }
                            }
                            Button("Hide activity") { Task { await model.endFollowed() } }
                        }
                    }
                    Section("Active chats") {
                        if model.runs.isEmpty { Text("Start a chat in the Chat tab.").foregroundStyle(.secondary) }
                        ForEach(model.runs) { run in
                            VStack(alignment: .leading, spacing: 8) {
                                Label(run.content.label, systemImage: run.content.symbol)
                                Text(Date(timeIntervalSince1970: run.startedAt), style: .time).font(.caption)
                                HStack {
                                    Button("Follow") { Task { await model.follow(run) } }.buttonStyle(.bordered)
                                    Button("Open chat") { model.openChat(run.sessionID) }.buttonStyle(.bordered)
                                }
                            }.padding(.vertical, 4)
                        }
                    }
                    Section("Layout demo · simulated") {
                        Button("Show demo activity") { Task { await model.startDemo() } }
                        if model.followed?.attributes.isDemo == true {
                            Button("Needs approval") { Task { await model.demoState("awaiting_permission") } }
                            Button("Working") { Task { await model.demoState("running") } }
                            Button("Reply ready") { Task { await model.demoState("completed") } }
                            Button("Work failed") { Task { await model.demoState("failed") } }
                        }
                        Text("Choose a state, then go to the Home Screen or lock your phone to inspect it. Demo buttons do not start work or grant permissions.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Section {
                        Text(model.status).font(.footnote)
                        if let error = model.error { Text(error).foregroundStyle(.orange) }
                    }
                }.navigationTitle("Activity")
            }.tabItem { Label("Activity", systemImage: "waveform") }.tag(1)
            NavigationStack {
                Form {
                    Section("Kairos server") {
                        TextField("HTTPS address", text: $model.serverText)
                            .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                        Button("Connect") { Task { await model.connect() } }
                        Text("Use your private HTTPS preview address. Keep Tailscale connected and the Kairos host running.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Section("Prototype scope") {
                        Text("iPhone · iOS 17 or later")
                        Text("Dynamic Island on supported models; Lock Screen on other iPhones.")
                        Text("Background completion and approval updates require APNs and are not enabled in this build. Keep your Home Screen app for the existing Web Push alerts.")
                    }
                    if let error = model.error { Text(error).foregroundStyle(.orange) }
                }.navigationTitle("Setup")
            }.tabItem { Label("Setup", systemImage: "gearshape") }.tag(2)
        }
    }
}
